#include "lrun.h"
#include "as_web.h"
#include "lrw_custom_body.h"
#include "wssoap.h"

#define BEGIN_ARGUMENTS				"BEGIN_ARGUMENTS"
#define END_ARGUMENTS				"END_ARGUMENTS"
#define BEGIN_RESULT				"BEGIN_RESULT"
#define END_RESULT					"END_RESULT"
#define BEGIN_EVENTS            "BEGIN_EVENTS"
#define END_EVENTS              "END_EVENTS"

