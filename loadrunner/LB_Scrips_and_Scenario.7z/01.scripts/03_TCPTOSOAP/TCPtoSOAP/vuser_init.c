#include "lrs.h"


vuser_init()
{
    lrs_startup(257);	

    return 0;
}

