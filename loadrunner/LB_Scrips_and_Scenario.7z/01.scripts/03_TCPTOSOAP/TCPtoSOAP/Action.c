#include "lrs.h"

Action()
{

	int rc=-9;

	lr_start_transaction("03_TCPTOSOAP");

	lrs_create_socket("socket1", "TCP", "LocalHost=0", "RemoteHost={IP}:9002",  LrsLastArg); //EGI AP 10.220.212.164~167   

	lrs_send("socket1", "buf1", LrsLastArg);

   lrs_set_recv_timeout(60, 0); // Time Out : 1 Min

    rc = lrs_receive("socket1", "buf2", LrsLastArg);

  //	rc = lrs_receive_ex("socket1", "buf2", "NumberOfBytesToRecv=73", LrsLastArg); //buf2 ���� 300 bite �޾Ƽ�

	if (rc==0) {

		//lr_output_message ("@@lrs_receive_ex error code: %d", rc);

		lrs_save_searched_string("socket1", NULL, "success_flag", NULL, NULL, -1,20,14); //21��°���� 14 length�� success_flag �� ����
        lrs_save_searched_string("socket1", NULL, "Rec_Data", NULL, NULL, -1,0,73); //73byte
		//lr_output_message ("success_flag: %s", lr_eval_string("{success_flag}"));

        if (strcmp(lr_eval_string("{success_flag}"),"20150714164200") ==0) {
      
			lrs_close_socket("socket1");
		    lr_end_transaction("03_TCPTOSOAP", LR_PASS);

	    } else {
		
			lrs_close_socket("socket1");
		    lr_end_transaction("03_TCPTOSOAP", LR_FAIL);
	        lr_error_message ("Fail :  Find 20150714164200, Recv= %s", lr_eval_string("{success_flag}"));
            lr_error_message ("Fail Receive All Data:: %s",  lr_eval_string("{Rec_Data}"));

	    }
    } else {
		lrs_close_socket("socket1");
	    lr_end_transaction("03_TCPTOSOAP", LR_FAIL);
        lr_error_message ("receive Fail: %d", rc);
    }


    return 0;
}


